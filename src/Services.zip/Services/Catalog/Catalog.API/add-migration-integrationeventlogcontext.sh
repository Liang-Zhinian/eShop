#!/bin/sh

dotnet ef migrations add Initial --context IntegrationEventLogContext
