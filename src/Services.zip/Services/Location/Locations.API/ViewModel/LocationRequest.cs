﻿namespace Eva.eShop.Services.Locations.API.ViewModel
{
    public class LocationRequest
    {
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
