﻿namespace Eva.eShop.Services.Locations.API.Infrastructure.Services
{
    public interface IIdentityService
    {
        string GetUserIdentity();
    }
}
