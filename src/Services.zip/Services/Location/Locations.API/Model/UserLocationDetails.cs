﻿namespace Eva.eShop.Services.Locations.API.Model
{
    public class UserLocationDetails
    {
        public int LocationId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
}