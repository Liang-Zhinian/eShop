﻿namespace Eva.eShop.Services.Identity.API.Models.ManageViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
