﻿namespace Eva.eShop.Services.Marketing.API.Infrastructure.Services
{
    public interface IIdentityService
    {
        string GetUserIdentity();
    }
}
