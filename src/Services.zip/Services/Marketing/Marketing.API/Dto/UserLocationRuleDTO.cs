﻿namespace Eva.eShop.Services.Marketing.API.Dto
{
    public class UserLocationRuleDTO
    {
        public int Id { get; set; }

        public int LocationId { get; set; }

        public string Description { get; set; }
    }
}