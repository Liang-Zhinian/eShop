﻿namespace Eva.eShop.Services.Marketing.API.Model
{
    public class Location
    {
        public int LocationId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
