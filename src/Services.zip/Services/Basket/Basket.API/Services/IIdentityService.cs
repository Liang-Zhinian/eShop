﻿namespace Eva.eShop.Services.Basket.API.Services
{
    public interface IIdentityService
    {
        string GetUserIdentity();
    }
}
