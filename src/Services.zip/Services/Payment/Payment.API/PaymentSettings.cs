﻿namespace Payment.API
{
    public class PaymentSettings
    {
        public bool PaymentSucceded { get; set; }
        public string EventBusConnection { get; set; }
    }
}
