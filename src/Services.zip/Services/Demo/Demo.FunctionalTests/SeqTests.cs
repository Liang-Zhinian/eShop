using System;
using Xunit;

namespace Demo.API.Tests
{
    public class SeqTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
