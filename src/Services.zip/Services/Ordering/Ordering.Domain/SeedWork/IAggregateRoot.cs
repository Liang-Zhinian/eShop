﻿namespace Eva.eShop.Services.Ordering.Domain.Seedwork
{
   
    public interface IAggregateRoot { }

}
