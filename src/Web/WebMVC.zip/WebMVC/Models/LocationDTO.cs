﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebMVC.Models
{
    public class LocationDTO
    {
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
