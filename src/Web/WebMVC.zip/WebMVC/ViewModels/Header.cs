﻿using System;

namespace SaaSEqt.eShop.WebMVC.ViewModels
{
    public class Header
    {
        public string Controller { get; set; }
        public string Text { get; set; }
    }
}